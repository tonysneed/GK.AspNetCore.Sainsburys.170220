﻿namespace $safeprojectname$.Models
{
    public class HomeViewModel
    {
        public string Name { get; set; }
    }
}
